

var a = prompt('Enter the first variable: ');

function setup(){
  var b2 = createButton("click here to Swap");

  }


function draw()
{
}
